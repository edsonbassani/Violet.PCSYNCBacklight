﻿using System;
using System.IO.Ports;

class Program
{
    static void Main()
    {
        // Configure the SerialPort
        SerialPort serialPort = new SerialPort("COM4", 9600, Parity.None, 8, StopBits.One);

        try
        {
            // Open the port
            serialPort.Open();
            Console.WriteLine("Connected to device on COM4.");

            // Turn On LEDs
            Console.WriteLine("\n--- Turning On LEDs ---");
            TurnOn(serialPort);
            ReadResponse(serialPort);
            System.Threading.Thread.Sleep(100); // Allow processing

            // Set Red
            Console.WriteLine("\n--- Set Red ---");
            SetColor("Red", serialPort);
            ReadResponse(serialPort);
            System.Threading.Thread.Sleep(100); // Allow processing

            // Set Green
            Console.WriteLine("\n--- Set Green ---");
            SetColor("Green", serialPort);
            ReadResponse(serialPort);
            System.Threading.Thread.Sleep(100); // Allow processing

            // Set Blue
            Console.WriteLine("\n--- Set Blue ---");
            SetColor("Blue", serialPort);
            ReadResponse(serialPort);
            System.Threading.Thread.Sleep(100); // Allow processing

            // Set Yellow
            Console.WriteLine("\n--- Set Yellow ---");
            SetColor("Yellow", serialPort);
            ReadResponse(serialPort);
            System.Threading.Thread.Sleep(100); // Allow processing

            // Set Magenta
            Console.WriteLine("\n--- Set Magenta ---");
            SetColor("Magenta", serialPort);
            ReadResponse(serialPort);
            System.Threading.Thread.Sleep(100); // Allow processing

            // Set Cyan
            Console.WriteLine("\n--- Set Cyan ---");
            SetColor("Cyan", serialPort);
            ReadResponse(serialPort);
            System.Threading.Thread.Sleep(100); // Allow processing

            // Set White
            Console.WriteLine("\n--- Set White ---");
            SetColor("White", serialPort);
            ReadResponse(serialPort);
            System.Threading.Thread.Sleep(100); // Allow processing

            // Turn Off LEDs
            Console.WriteLine("\n--- Turning Off LEDs ---");
            TurnOff(serialPort);
            ReadResponse(serialPort);
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Error: {ex.Message}");
        }
        finally
        {
            // Ensure proper cleanup
            if (serialPort.IsOpen)
            {
                serialPort.Close();
                Console.WriteLine("Connection closed.");
            }
        }
    }

    // Command to turn ON the LED stripe
    public static void TurnOn(SerialPort port)
    {
        // byte[] command = { 0x52, 0x42, 0x10, 0x30, 0x86, 0x01, 0x55, 0x55, 0x55, 0x4b, 0x00, 0x00, 0x00, 0xfe, 0xef}; // Restored Turn On Payload
        //byte[] command = { 0x52, 0x42, 0x10, 0x89, 0x86, 0x01, 0x55, 0x55, 0x55, 0x4b, 0x4c, 0x00, 0x00, 0x00, 0xfe, 0x48 }; // Restored Turn On Payload
        byte[] command = new byte[] { 0x52, 0x42, 0x10, 0x9e, 0x86, 0x01, 0x55, 0x55, 0x55, 0x4b, 0x4c, 0x55, 0x55, 0x55, 0xfe, 0x5c };
        SendCommand(port, command, "Turn ON");
    }

    // Command to turn OFF the LED stripe
    public static void TurnOff(SerialPort port)
    {
        //byte[] command = { 0x52, 0x42, 0x10, 0x22, 0x86, 0x01, 0x00, 0x00, 0x00, 0xfe, 0xe2 }; // Turn Off Payload
        byte[] command = { 0x52, 0x42, 0x10, 0x8f, 0x86, 0x01, 0x00, 0x00, 0x00, 0x4b, 0x4c, 0x00, 0x00, 0x00, 0xfe, 0x4f }; // Turn Off Payload
        SendCommand(port, command, "Turn OFF");
    }

    public static void SetColor(string color, SerialPort port)
    {
        byte[] command;

        switch (color.ToLower())
        {
            case "red":
                command = new byte[]{ 0x52, 0x42, 0x10, 0x3c, 0x86, 0x01, 0xff, 0x00, 0x00, 0x4b, 0x4c, 0x00, 0x00, 0x00, 0xfe, 0xfb };
                break;
            case "green":
                command = new byte[] { 0x52, 0x42, 0x10, 0x6e, 0x86, 0x01, 0x00, 0xff, 0x00, 0x4b, 0x4c, 0x00, 0x00, 0x00, 0xfe, 0x2d };
                break;
            case "blue":
                command = new byte[] { 0x52, 0x42, 0x10, 0x74, 0x86, 0x01, 0x00, 0x00, 0xff, 0x4b, 0x4c, 0x00, 0x00, 0x00, 0xfe, 0x33 };
                break;
            case "yellow":
                command = new byte[] { 0x52, 0x42, 0x10, 0x76, 0x86, 0x01, 0x7f, 0x7f, 0x00, 0x4b, 0x4c, 0x00, 0x00, 0x00, 0xfe, 0x34 };
                break;
            case "magenta":
                command = new byte[] { 0x52, 0x42, 0x10, 0x78, 0x86, 0x01, 0x7f, 0x00, 0x7f, 0x4b, 0x4c, 0x00, 0x00, 0x00, 0xfe, 0x36 };
                break;
            case "cyan":
                command = new byte[] { 0x52, 0x42, 0x10, 0x7e, 0x86, 0x01, 0x00, 0x7f, 0x7f, 0x4b, 0x4c, 0x00, 0x00, 0x00, 0xfe, 0x3c };
                break;
            case "white":
                command = new byte[] { 0x52, 0x42, 0x10, 0x9e, 0x86, 0x01, 0x55, 0x55, 0x55, 0x4b, 0x4c, 0x55, 0x55, 0x55, 0xfe, 0x5c };
                break;
            default: 
                command = new byte[] { 0x52, 0x42, 0x10, 0x89, 0x86, 0x01, 0x55, 0x55, 0x55, 0x4b, 0x4c, 0x00, 0x00, 0x00, 0xfe, 0x48 };
                break;
        }

        SendCommand(port, command, $"Set Color: {color}");

    }

    // General method to send a command and print the response
    private static void SendCommand(SerialPort port, byte[] command, string action)
    {
        Console.WriteLine($"Sending Command ({action}): {BitConverter.ToString(command)}");
        port.Write(command, 0, command.Length);

        System.Threading.Thread.Sleep(500); // Wait for device response
    }

    // Method to read and log response from the device
    private static byte[]? ReadResponse(SerialPort port)
    {
        if (port.BytesToRead > 0)
        {
            byte[] response = new byte[port.BytesToRead];
            port.Read(response, 0, response.Length);
            Console.WriteLine($"Received Response: {BitConverter.ToString(response)}");
            return response;
        }
        else
        {
            Console.WriteLine("No response received.");
            return null;
        }
    }
}
